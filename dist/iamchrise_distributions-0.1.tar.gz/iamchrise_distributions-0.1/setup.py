from setuptools import setup

setup(name='iamchrise_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['iamchrise_distributions'],
      author = 'Christian Emiyah',
      author_email = 'christian.emiyah@gmail.com',
      url = 'https://github.com/emichris/Distribution-Pakage-Files',
      zip_safe=False)
